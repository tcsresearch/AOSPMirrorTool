echo "AOSP Home Directory:  	$AOSP_HomeDir "
echo "Config Dir:  		$ConfigDir    "
echo "Config File: 		$ConfigFile   "
echo "Functions Dir: 		$FunctionsDir "


