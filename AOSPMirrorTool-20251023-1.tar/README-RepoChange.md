Starting March 27, 2025, we recommend using android-latest-release instead of aosp-main to build and contribute to AOSP. 
For more information, see Changes to AOSP.
